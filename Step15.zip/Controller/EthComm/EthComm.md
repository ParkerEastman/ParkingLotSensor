To communicate data across a network, a Wizbee chipset has been utilized.  Implemented 
as an arduino shield, the default sketch "WebClient" has been modified to send 
arbitrary data to an IP Address associated with a computer that has opened a listener 
on an agreed upon port.  Further advances will pass counter data in post requests 
through a similar manner
